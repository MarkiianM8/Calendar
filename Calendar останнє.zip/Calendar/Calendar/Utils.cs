﻿using System;

namespace Calendar;

public class Utils
{
    public static bool CheckPasssword(string password)
    {
        return System.Text.RegularExpressions.Regex.IsMatch(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,127}$");
    }

    public static bool IsAfter(TimeOnly from, TimeOnly to)
    {
        if (from.Hour < to.Hour)
        {
            return true;
        }
        else if (from.Hour == to.Hour)
        {
            return from.Minute < to.Minute;
        }

        return false;
    }

}
