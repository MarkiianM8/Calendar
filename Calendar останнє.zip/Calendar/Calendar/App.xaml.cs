﻿using System.Windows;

namespace Calendar;

public partial class App : Application
{
}
