﻿namespace Calendar; 

using Db.Context;
using Db.Models;
using Db.Services;
using System.Windows;

/// <summary>
/// Interaction logic for SignUpForm.xaml
/// </summary>
public partial class SignUpForm : Window
{
    private UserService _userService;
    
    public SignUpForm()
    {
        this._userService = new(CalendarDbContextSingleton.Instance);
        InitializeComponent();
    }

    private void SignUpBtn_Click(object sender, RoutedEventArgs e)
    {
        if (this.txtPassword.Password != this.txtPasswordConfirm.Password)
        {
            MessageBox.Show("Password does not match!", "Fail", MessageBoxButton.OK);
            this.txtPasswordConfirm.Password = string.Empty;
            return;
        }
        
        if (this.txtUsername.Text.Length < 3)
        {
            MessageBox.Show("Username must be at least 3 characters long!", "Fail", MessageBoxButton.OK);
            this.txtUsername.Text = string.Empty;
            return;
        }
        
        if (!Utils.CheckPasssword(this.txtPassword.Password))
        {
            MessageBox.Show("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number and one special character!", "Fail", MessageBoxButton.OK);
            this.txtPassword.Password = string.Empty;
            this.txtPasswordConfirm.Password = string.Empty;
            return;
        }

        User user = new User(this.txtUsername.Text, this.txtPassword.Password);

        if (this._userService.Add(user) != null)
        {
            LoggedInUserSingleton.Instance = user;
            MessageBox.Show("Instance created successfully!", "Success", MessageBoxButton.OK);
            this.Close();
        }
        else
        {
            MessageBox.Show("Instance already exists!", "Fail", MessageBoxButton.OK);
            this.txtUsername.Text = string.Empty;
            this.txtPassword.Password = string.Empty;
            this.txtPasswordConfirm.Password = string.Empty;
        }
    }
}
