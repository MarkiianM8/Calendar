﻿namespace Calendar;

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

public partial class MainWindow : Window
{

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Calendar_OnSelectedDatesChanged(object sender, SelectionChangedEventArgs e)
    {
        if (LoggedInUserSingleton.Instance == null)
        {
            MessageBox.Show("Please authorize first.");
            return;
        }

        List<DateOnly> selectedDaysList = new ();
        foreach (DateTime? day in this.CustomCalendar.SelectedDates)
        {
            if (day is null)
            {
                continue;
            }

            selectedDaysList.Add(DateOnly.FromDateTime(day.Value));
        }

        var eventForm = new EventsList(selectedDaysList);
        eventForm.Show();
    }

    private void LogIn_Click(object sender, RoutedEventArgs e)
    {
        var loginForm = new LogInForm();
        loginForm.Show();
    }

    private void LogOut_Click(object sender, RoutedEventArgs e)
    {
        LoggedInUserSingleton.Instance = null;
        MessageBox.Show("Logged out.");
    }

    private void SignUp_Click(object sender, RoutedEventArgs e)
    {
        var signUpForm = new SignUpForm();
        signUpForm.Show();
    }
}
