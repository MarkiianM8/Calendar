﻿namespace Calendar;

using Db.Context;
using Db.Services;
using System.Windows;

/// <summary>
/// Interaction logic for LogInForm.xaml
/// </summary>
public partial class LogInForm : Window
{
    private UserService _userService;
    public LogInForm()
    {
        this._userService = new(CalendarDbContextSingleton.Instance);
        InitializeComponent();
    }

    private void loginBtn_Click(object sender, RoutedEventArgs e)
    {
        var user = this._userService.GetByUsername(txtUsername.Text);
        if (user is null || user.Password != txtPassword.Password)
        {
            MessageBox.Show("Invalid username or password!", "Fail", MessageBoxButton.OK);
            txtUsername.Text = string.Empty;
            txtPassword.Password = string.Empty;
            return;
        }

        LoggedInUserSingleton.Instance = user;
        MessageBox.Show("Logged in successfully!", "Success", MessageBoxButton.OK);
        this.Close();
    }
}
