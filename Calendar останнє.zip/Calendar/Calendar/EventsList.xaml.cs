﻿namespace Calendar;

using Db.Context;
using Db.Services;
using System.Collections.Generic;
using System;
using System.Windows;

/// <summary>
/// Interaction logic for EventsList.xaml
/// </summary>
public partial class EventsList : Window
{
    public List<DateOnly> SelectedDays;
    public EventService EventService;

    public EventsList(List<DateOnly> selectedDays)
    {
        this.SelectedDays = selectedDays;
        this.EventService = new EventService(CalendarDbContextSingleton.Instance);
        InitializeComponent();
        this.UpdateEvents();
    }

    public void UpdateEvents()
    {
        // clear this.EventsGrid
        this.EventsGrid.Items.Clear();

        var events = this.EventService.GetByDatesAndUserId(this.SelectedDays, LoggedInUserSingleton.Instance!.Id);

        foreach (var @event in events!)
        {
            this.EventsGrid.Items.Add(@event);
        }
    }

    private void AddEventBtn_Click(object sender, RoutedEventArgs e)
    {
        var eventForm = new EventForm(this);
        eventForm.Show();
    }

    private void ShowDetailsBtn_Click(object sender, RoutedEventArgs e)
    {
    }
}
