﻿namespace Calendar;

using Db.Models;
using System;
using System.Collections.Generic;
using System.Windows;

/// <summary>
/// Interaction logic for EventForm.xaml
/// </summary>
public partial class EventForm : Window
{
    private EventsList eventsListWindow;
    public EventForm(EventsList eventsListWindow)
    {
        this.eventsListWindow = eventsListWindow;
        InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        if (this.Title.Text.Length < 3)
        {
            MessageBox.Show("Title must be at least 3 characters long");
            return;
        }

        if (Utils.IsAfter(TimeOnly.FromDateTime((DateTime)StartTimePicker.SelectedTime!), TimeOnly.FromDateTime((DateTime)EndTimePicker.SelectedTime!)))
        {
            MessageBox.Show("Start time must be before end time");
            return;
        }

        List<Event> newEvents = new ();
        foreach (var date in this.eventsListWindow.SelectedDays)
        {
            newEvents.Add(new Event
            {
                Title = this.Title.Text,
                Description = string.Empty,
                Date = date,
                StartTime = TimeOnly.FromDateTime((DateTime)StartTimePicker.SelectedTime!),
                EndTime = TimeOnly.FromDateTime((DateTime)this.EndTimePicker.SelectedTime!),
            });
        }

        this.eventsListWindow.EventService.AddEvents(LoggedInUserSingleton.Instance!.Id, newEvents);
        this.eventsListWindow.UpdateEvents();
        this.Close();
    }
}
