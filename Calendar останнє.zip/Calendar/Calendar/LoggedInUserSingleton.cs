﻿namespace Calendar;

using Db.Models;

public class LoggedInUserSingleton
{
    private static User? _instance = null;
    
    public static User? Instance
    {
        get => _instance;
        set => _instance = value;
    }
}
