﻿// <copyright file="Event.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Db.Models;

using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

/// <summary>
/// Event entity.
/// </summary>
public class Event
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Event"/> class.
    /// No arguments constructor.
    /// </summary>
    public Event()
    {
        this.Id = 0;
        this.Date = DateOnly.FromDateTime(DateTime.Now);
        this.StartTime = TimeOnly.Parse("00:00");
        this.EndTime = TimeOnly.Parse("23:59");
        this.Title = string.Empty;
        this.Description = string.Empty;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="Event"/> class.
    /// All arguments constructor.
    /// </summary>
    /// <param name="date">Event date.</param>
    /// <param name="startTime">Event start time.</param>
    /// <param name="endTime">Event end time.</param>
    /// <param name="title">Event title.</param>
    /// <param name="description">Event description.</param>
    public Event(DateOnly date, TimeOnly startTime, TimeOnly endTime, string title, string description)
    {
        this.Id = 0;
        this.Date = date;
        this.StartTime = startTime;
        this.EndTime = endTime;
        this.Title = title;
        this.Description = description;
    }

    /// <summary>
    /// Gets or sets entity identificator.
    /// </summary>
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// Gets or sets date.
    /// </summary>
    [Required]
    public DateOnly Date { get; set; }

    /// <summary>
    /// Gets or sets start time.
    /// </summary>
    [AllowNull]
    public TimeOnly? StartTime { get; set; }

    /// <summary>
    /// Gets or sets end time.
    /// </summary>
    [AllowNull]
    public TimeOnly? EndTime { get; set; }

    /// <summary>
    /// Gets or sets title.
    /// </summary>
    [Required]
    [MinLength(3)]
    public string Title { get; set; }

    /// <summary>
    /// Gets or sets description.
    /// </summary>
    [AllowNull]
    public string Description { get; set; }

    /// <summary>
    /// Equls.
    /// </summary>
    /// <param name="obj">Other Object.</param>
    /// <returns>Bool.</returns>
    public override bool Equals(object? obj)
    {
        return obj is Event @event &&
               this.Id == @event.Id &&
               this.Date == @event.Date &&
               this.StartTime == @event.StartTime &&
               this.EndTime == @event.EndTime &&
               this.Title == @event.Title &&
               this.Description == @event.Description;
    }

    /// <summary>
    /// Get hash code.
    /// </summary>
    /// <returns>Hash code.</returns>
    public override int GetHashCode()
    {
        return HashCode.Combine(this.Id, this.Date, this.StartTime, this.EndTime, this.Title, this.Description);
    }
}
