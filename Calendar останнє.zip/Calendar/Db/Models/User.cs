﻿// <copyright file="User.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Db.Models;

using System.ComponentModel.DataAnnotations;

/// <summary>
/// User entity.
/// </summary>
public class User
{
    /// <summary>
    /// Initializes a new instance of the <see cref="User"/> class.
    /// No arguments constructor.
    /// </summary>
    public User()
    {
        this.Id = 0;
        this.Username = string.Empty;
        this.Password = string.Empty;
        this.Events = new ();
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="User"/> class.
    /// All arguments constructor.
    /// </summary>
    /// <param name="id">Entity identificator.</param>
    /// <param name="username">Username.</param>
    /// <param name="password">User password.</param>
    public User(string username, string password)
    {
        this.Id = 0;
        this.Username = username;
        this.Password = password;
        this.Events = new ();
    }

    /// <summary>
    /// Gets or sets entity identificator.
    /// </summary>
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// Gets or sets the user name.
    /// </summary>
    [Required]
    public string? Username { get; set; }

    /// <summary>
    /// Gets or sets the user password.
    /// </summary>
    [Required]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,127}$")]
    public string? Password { get; set; }

    /// <summary>
    /// Gets or sets the user email.
    /// </summary>
    [Required]
    public List<Event> Events { get; set; }

    /// <summary>
    /// Equals.
    /// </summary>
    /// <param name="obj">Other user.</param>
    /// <returns>Bool.</returns>
    public override bool Equals(object? obj)
    {
        return obj is User user &&
               this.Username == user.Username;
    }

    /// <summary>
    /// Get hash code.
    /// </summary>
    /// <returns>Hash code.</returns>
    public override int GetHashCode()
    {
        return HashCode.Combine(this.Username, this.Password);
    }
}
