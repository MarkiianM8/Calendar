﻿// <copyright file="CalendarDbContext.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Db.Context;

using Db.Models;
using Microsoft.EntityFrameworkCore;

/// <summary>
/// Calendar Database context.
/// Implements singleton pattern.
/// </summary>
public class CalendarDbContext : DbContext
{
    /// <summary>
    /// Gets or sets events.
    /// </summary>
    public DbSet<User>? Users { get; set; }

    /// <summary>
    /// Configure the database.
    /// </summary>
    /// <param name="optionsBuilder">Option builder.</param>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseNpgsql("Host=localhost;Database=CalendarDb;Username=postgres;Password=4");

}
