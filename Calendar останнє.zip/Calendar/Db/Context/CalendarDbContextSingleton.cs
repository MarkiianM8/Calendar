﻿// <copyright file="CalendarDbContextInstance.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Db.Context;

/// <summary>
/// Calendar Database context singleton.
/// </summary>
public class CalendarDbContextSingleton
{
    /// <summary>
    /// Gets instance.
    /// </summary>
    public static CalendarDbContext Instance { get; } = new ();
}
