﻿// <copyright file="UserService.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Db.Services;

using Db.Context;
using Db.Models;

/// <summary>
/// User service.
/// </summary>
public class UserService
{
    private CalendarDbContext context;

    /// <summary>
    /// Initializes a new instance of the <see cref="UserService"/> class.
    /// </summary>
    /// <param name="context">Context.</param>
    public UserService(CalendarDbContext context)
    {
        this.context = context;
    }

    /// <summary>
    /// Add user to database.
    /// </summary>
    /// <param name="user">User.</param>
    /// <returns>Added user.</returns>
    public User? Add(User user)
    {
        if (this.context.Users?
            .Where(u => u.Username == user.Username)
            .FirstOrDefault() is null)
        {
            this.context.Users?.Add(user);
            this.context.SaveChanges();
            return user;
        }

        return null;
    }

    /// <summary>
    /// Retrieve user from db by username.
    /// </summary>
    /// <param name="username">User username.</param>
    /// <returns>User.</returns>
    public User? GetByUsername(string username)
    {
        var user = this.context.Users?
            .Where(u => u.Username == username)
            .FirstOrDefault();
        return user;
    }
}
