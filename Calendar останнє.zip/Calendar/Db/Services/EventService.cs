﻿// <copyright file="EventService.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
namespace Db.Services;

using Db.Context;
using Db.Models;

/// <summary>
/// Event service.
/// </summary>
public class EventService
{
    private CalendarDbContext context;

    /// <summary>
    /// Initializes a new instance of the <see cref="EventService"/> class.
    /// </summary>
    /// <param name="context">Context.</param>
    public EventService(CalendarDbContext context)
    {
        this.context = context;
    }

    /// <summary>
    /// Add new Event.
    /// </summary>
    /// <param name="userId">User id.</param>
    /// <param name="event">Event.</param>
    /// <returns>Added newEvent.</returns>
    public Event? AddEvent(int userId, Event @event)
    {
        User? user = this.context.Users?.Find(userId);
        if (user is null
            || user.Events.Where(e => e == @event).FirstOrDefault() is not null)
        {
            return null;
        }

        user.Events.Add(@event);
        this.context.Users?.Update(user);
        this.context.SaveChanges();
        return @event;
    }

    /// <summary>
    /// Add collection of new Events.
    /// </summary>
    /// <param name="userId">User id.</param>
    /// <param name="events">List of events.</param>
    /// <returns>Added list.</returns>
    public List<Event>? AddEvents(int userId, List<Event> events)
    {
        User? user = this.context.Users?.Find(userId);
        if (user is null)
        {
            return null;
        }

        foreach (var @event in events)
        {
            if (user.Events.Where(e => e == @event).FirstOrDefault() is null)
            {
                user.Events.Add(@event);
            }
        }

        this.context.Users?.Update(user);
        this.context.SaveChanges();
        return events;
    }

    /// <summary>
    /// Delete newEvent.
    /// </summary>
    /// <param name="userId">User id.</param>
    /// <param name="eventId">Event id.</param>
    /// <returns>Deleted user.</returns>
    public Event? DeleteEvent(int userId, int eventId)
    {
        User? user = this.context.Users?.Find(userId);
        if (user is null)
        {
            return null;
        }

        Event? @event = user.Events.Find(e => e.Id == eventId);
        if (@event is null)
        {
            return null;
        }

        user.Events.Remove(@event);
        this.context.Users?.Update(user);
        this.context.SaveChanges();
        return @event;
    }

    /// <summary>
    /// Update newEvent.
    /// </summary>
    /// <param name="userId">User id.</param>
    /// <param name="eventId">Event id.</param>
    /// <param name="newEvent">New newEvent.</param>
    /// <returns>Updated event.</returns>
    public Event? UpdateEvent(int userId, int eventId, Event newEvent)
    {
        User? user = this.context.Users?.Find(userId);
        if (user is null)
        {
            return null;
        }

        Event? @event = user.Events.Find(e => e.Id == eventId);
        if (@event is null || @event.Date != newEvent.Date)
        {
            return null;
        }

        @event.StartTime = newEvent.StartTime;
        @event.EndTime = newEvent.EndTime;
        @event.Title = newEvent.Title;
        @event.Description = newEvent.Description;

        this.context.Users?.Update(user);
        this.context.SaveChanges();
        return @event;
    }

    /// <summary>
    /// Get Events by user id and selected days.
    /// </summary>
    /// <param name="dates">Selected dates.</param>
    /// <param name="userId">User id.</param>
    /// <returns>List of events.</returns>
    public List<Event>? GetByDatesAndUserId(List<DateOnly> dates, int userId)
    {
        User? user = this.context.Users?.Find(userId);
        if (user is null)
        {
            return null;
        }

        List<Event> events = new List<Event>();
        foreach (DateOnly date in dates)
        {
            events.AddRange(user.Events.Where(e => e.Date == date));
        }

        return events;
    }
}
